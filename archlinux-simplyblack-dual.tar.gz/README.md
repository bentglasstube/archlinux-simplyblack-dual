archlinux-simplyblack-dual
==========================

A Slim <http://slim.berlios.de/> theme based on archlinux-simplyblack
<https://www.archlinux.org/packages/extra/any/archlinux-themes-slim/> but
modified for a dual monitor setup.

INSTALLATION
------------

Copy the entire contents of this archive to /usr/share/slim/themes/

LICENSE
-------
These works are licensed Creative Commons.
For full license details, refer to the LICENSE file.
For attribution, refer to the AUTHORS file.
